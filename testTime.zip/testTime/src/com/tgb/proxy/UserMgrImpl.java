package com.tgb.proxy;

public class UserMgrImpl implements UserMgr {

	@Override
	public void addUser() {
		System.out.println("�����û�.....");
	}

	@Override
	public void delUser() {
		System.out.println("ɾ���û�.....");
	}

}
