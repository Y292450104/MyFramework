package com.tgb.proxy;

public interface UserMgr {
	void addUser();

	void delUser();
}
