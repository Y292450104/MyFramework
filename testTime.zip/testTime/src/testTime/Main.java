package testTime;

import java.util.Date;

public class Main {
	public static void main(String[] args) {
		
		long time = 1452120288000L;
		Date date = new Date(time);
		System.out.print("time:"+date);
	}
}
